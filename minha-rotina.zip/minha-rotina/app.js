/* Minha Rotina — app.js. Tudo roda no aparelho; dados em localStorage. */
'use strict';
const KEY='minhaRotina.v1';
const $=(s,e=document)=>e.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const pad=n=>String(n).padStart(2,'0');
const iso=d=>`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
const fromIso=s=>{const[y,m,d]=s.split('-').map(Number);return new Date(y,m-1,d)};
const hm=d=>`${pad(d.getHours())}:${pad(d.getMinutes())}`;
const DOW=['D','S','T','Q','Q','S','S'];
const DOWF=['Domingo','Segunda-feira','Terça-feira','Quarta-feira','Quinta-feira','Sexta-feira','Sábado'];
const DOWS=['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'];
const MES=['janeiro','fevereiro','março','abril','maio','junho','julho','agosto','setembro','outubro','novembro','dezembro'];
const fmtLong=d=>`${DOWF[d.getDay()]}, ${d.getDate()} de ${MES[d.getMonth()]}`;
const MSGS=['Um passo de cada vez já é caminho.','Constância vence intensidade.','Faça o simples, faça hoje.','O você de amanhã agradece o que você fizer agora.','Disciplina é um favor que você faz a si mesmo.','Pequenos hábitos, grande resultado.','Hoje conta. Marque a próxima tarefa.'];

/* ---------- Dados ---------- */
const T=(id,time,title,items,x={})=>({id,time,title,items,opt:false,days:null,kind:'',...x});
const DEFAULT_TASKS=[
T('acordar','05:00','Acordar',['Beber água','Arrumar a cama','Higiene pessoal','Compressa fria no rosto, se desejar']),
T('cardio','05:10','Cardio',['Caminhada de 15 a 20 minutos'],{kind:'cardio'}),
T('banho','05:30','Banho e cuidados pessoais',['Banho','Limpeza facial','Hidratante','Protetor solar']),
T('cafe','05:45','Café da manhã',['3 ovos','2 fatias de pão integral','Banana com aveia','Café ou leite'],{kind:'food'}),
T('preparo','06:05','Preparação para o trabalho',['Vestir-se','Escovar os dentes','Conferir marmita, lanche, carteira e celular']),
T('sair','06:30','Sair de casa',['Pegar o ônibus para o trabalho']),
T('almoco','11:30','Almoço',['Comer a marmita','Beber água'],{kind:'food'}),
T('lanche','15:00','Lanche da tarde',['Iogurte com banana e aveia ou sanduíche com ovos','Beber água'],{kind:'food'}),
T('saida','17:00','Saída do trabalho',['Voltar para casa']),
T('chegada','19:00','Chegada em casa',['Trocar de roupa','Beber água','Fazer um lanche, se necessário']),
T('treino','19:15','Musculação ou recuperação',[],{kind:'gym'}),
T('jantar','20:00','Jantar',['Proteína','Arroz ou batata','Legumes e verduras'],{kind:'food'}),
T('preparar','20:25','Preparar o próximo dia',['Separar roupa','Organizar marmita','Preparar lanche','Arrumar mochila']),
T('dev','20:40','Desenvolvimento pessoal',['10 minutos de leitura','5 minutos de diário','Planejar o próximo dia'],{kind:'read'}),
T('dormir','21:00','Dormir',['Desligar telas','Preparar o ambiente','Dormir para garantir cerca de 8 horas de sono'])];
const norm=x=>{x.set={water:8,remind:false,train:[1,2,4,5],cardio:[1,2,3,4,5,6],...x.set};return x};
function load(){try{const s=JSON.parse(localStorage.getItem(KEY));if(s&&s.tasks&&s.days)return norm(s)}catch(e){}
 return norm({tasks:JSON.parse(JSON.stringify(DEFAULT_TASKS)),days:{}})}
let S=load();
const save=()=>{try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){toast('Sem espaço para salvar')}};
const peek=k=>S.days[k];
const day=k=>S.days[k]||(S.days[k]={done:{},water:0,sleep:null,h:{},diary:{}});
const hasData=r=>!!r&&(Object.values(r.done).some(Boolean)||r.water>0||r.sleep!=null||Object.values(r.h).some(Boolean)||Object.values(r.diary).some(v=>v&&v.trim()));

/* Tarefas aplicáveis a um dia (cardio e musculação seguem os dias configurados) */
function tasksFor(k){const d=fromIso(k).getDay();
 return S.tasks.filter(t=>(t.kind==='cardio'?S.set.cardio.includes(d):(!t.days||t.days.includes(d)))).map(t=>{
  let{title,opt,items}=t;
  if(t.kind==='gym'){const tr=S.set.train.includes(d);title=tr?'Musculação':d===0?'Descanso':d===6?'Atividade física e lazer':'Recuperação';opt=opt||!tr;if(!items.length)items=[tr?'Treino do dia':'Alongar, caminhar leve ou descansar']}
  return{...t,title,opt,items}}).sort((a,b)=>a.time.localeCompare(b.time))}
const pct=k=>{const r=peek(k),L=tasksFor(k).filter(t=>!t.opt);return L.length&&r?Math.round(L.filter(t=>r.done[t.id]).length/L.length*100):0};
const complete=k=>pct(k)===100;

/* ---------- Estado de tela ---------- */
let today=iso(new Date()),tab='hoje',cmode='mes',cfocus=new Date(),csel=today,dsel=today,lastMin='';
const open=new Set();
const IC={hoje:'<circle cx="12" cy="12" r="9"/><path d="M8 12.5l3 3 5-6"/>',cal:'<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M3 10h18M8 3v4M16 3v4"/>',prog:'<path d="M5 20v-8M12 20V5M19 20v-5"/>',diario:'<path d="M5 4h11a3 3 0 013 3v13H8a3 3 0 01-3-3z"/><path d="M9 9h6M9 13h6"/>',aj:'<path d="M4 7h10M18 7h2M4 17h2M10 17h10"/><circle cx="16" cy="7" r="2"/><circle cx="8" cy="17" r="2"/>'};
const TABS=[['hoje','Hoje'],['cal','Calendário'],['prog','Progresso'],['diario','Diário'],['aj','Ajustes']];
const svg=p=>`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${p}</svg>`;
let tt;function toast(m){const t=$('#toast');t.textContent=m;t.classList.add('show');clearTimeout(tt);tt=setTimeout(()=>t.classList.remove('show'),2600)}

/* ---------- Tela: Hoje ---------- */
const vHoje=()=>`<header class="hero"><p id="greet" class="mu"></p><h1>${fmtLong(new Date())}</h1><p id="clock" class="clock"></p></header>
<section class="card"><div class="pr"><b id="pct" class="big"></b><span id="cnt" class="mu"></span></div><div class="bar"><i id="bar"></i></div><p id="nx" class="nx"></p></section>
<section class="card" id="wt"></section><section class="card" id="hb"></section>
<h2>Tarefas de hoje</h2><ul id="tl" class="tl"></ul><p id="msg" class="quote"></p>`;
function nextHtml(L,r){const n=new Date(),t=L.find(t=>t.time>hm(n)&&!r.done[t.id]);
 if(!t)return L.filter(t=>!t.opt).every(t=>r.done[t.id])?'Tudo concluído por hoje.':'Sem mais horários hoje. Ainda há tarefas pendentes.';
 const[h,m]=t.time.split(':').map(Number),df=h*60+m-(n.getHours()*60+n.getMinutes());
 return`Próxima: <b>${t.time} ${esc(t.title)}</b> <span class="mu">em ${df>=60?`${Math.floor(df/60)}h${pad(df%60)}`:`${df} min`}</span>`}
const HAB=[['cardio','Cardio'],['gym','Musculação'],['read','Leitura'],['food','Alimentação organizada']];
function paintHoje(){const r=day(today),L=tasksFor(today),req=L.filter(t=>!t.opt),dn=req.filter(t=>r.done[t.id]).length,p=pct(today);
 $('#pct').textContent=p+'%';$('#cnt').textContent=req.length?`${dn} de ${req.length} tarefas`:'Sem tarefas obrigatórias';$('#bar').style.width=p+'%';
 $('#nx').innerHTML=nextHtml(L,r);
 $('#wt').innerHTML=`<div class="row"><div><b class="big">${r.water}</b><span class="mu"> / ${S.set.water} copos</span></div><div class="steps"><button class="rb" data-a="w-" aria-label="Tirar um copo">−</button><button class="rb on" data-a="w+" aria-label="Adicionar um copo">+</button></div></div><div class="dots">${Array.from({length:Math.max(S.set.water,r.water)},(_,i)=>`<i class="${i<r.water?'on':''}"></i>`).join('')}</div>`;
 const sl=$('#sleep');
 $('#hb').innerHTML=`<label class="fl">Horas de sono (noite passada)<input id="sleep" type="number" inputmode="decimal" step="0.5" min="0" max="16" placeholder="0" value="${r.sleep??''}" data-f="sleep"></label><div class="chips">${HAB.map(([k,n])=>`<button class="chip${r.h[k]?' on':''}" data-a="h" data-k="${k}">${n}</button>`).join('')}<span class="chip ro${p===100?' on':''}">Rotina concluída</span></div>`;
 $('#tl').innerHTML=L.map(t=>`<li class="${r.done[t.id]?'on':''}"><button class="chk" data-a="t" data-id="${t.id}" aria-label="Concluir ${esc(t.title)}">${svg('<path d="M5 12.5l4.5 4.5L19 7.5"/>')}</button><div class="tb" data-a="x" data-id="${t.id}"><div class="tt"><b>${esc(t.title)}</b>${t.opt?'<em>opcional</em>':''}<time>${t.time}</time></div>${open.has(t.id)&&t.items.length?`<ul>${t.items.map(i=>`<li>${esc(i)}</li>`).join('')}</ul>`:''}</div></li>`).join('')||'<li class="mu">Nenhuma tarefa hoje. Adicione em Ajustes.</li>';
 $('#msg').textContent=p===100?'Rotina completa. Descanse com orgulho.':MSGS[Math.floor(new Date()/864e5)%MSGS.length]}
function toggleTask(id){const r=day(today),v=!r.done[id],t=S.tasks.find(x=>x.id===id);r.done[id]=v;
 if(t&&['cardio','gym','read'].includes(t.kind))r.h[t.kind]=v;
 if(t&&t.kind==='food')r.h.food=tasksFor(today).filter(x=>x.kind==='food').every(x=>r.done[x.id]);
 save();paintHoje();if(navigator.vibrate)navigator.vibrate(8)}

/* ---------- Tela: Calendário ---------- */
const cell=(k,l,sub='')=>`<button class="cd ${k>today?'fut':complete(k)?'full':hasData(peek(k))?'part':''}${k===today?' now':''}${k===csel?' sel':''}" data-a="cs" data-k="${k}">${l}${sub}</button>`;
function vCal(){const f=new Date(cfocus);let head,cells=[];
 if(cmode==='mes'){const y=f.getFullYear(),m=f.getMonth(),n=new Date(y,m+1,0).getDate();head=`${MES[m]} de ${y}`;
  for(let i=0;i<new Date(y,m,1).getDay();i++)cells.push('<i></i>');for(let d=1;d<=n;d++)cells.push(cell(iso(new Date(y,m,d)),d))}
 else{const s=new Date(f);s.setDate(f.getDate()-f.getDay());head=`Semana de ${s.getDate()} de ${MES[s.getMonth()]}`;
  for(let i=0;i<7;i++){const d=new Date(s);d.setDate(s.getDate()+i);const k=iso(d);cells.push(cell(k,d.getDate(),`<small>${k<=today&&hasData(peek(k))?pct(k)+'%':'—'}</small>`))}}
 return`<header class="hero"><h1>Calendário</h1></header>
<div class="seg"><button class="${cmode==='mes'?'on':''}" data-a="cm" data-m="mes">Mês</button><button class="${cmode==='sem'?'on':''}" data-a="cm" data-m="sem">Semana</button></div>
<div class="nav"><button class="rb" data-a="cn" data-d="-1" aria-label="Anterior">‹</button><b>${head}</b><button class="rb" data-a="cn" data-d="1" aria-label="Próximo">›</button></div>
<div class="cg">${DOW.map(d=>`<span>${d}</span>`).join('')}${cells.join('')}</div>
<p class="mu small">Verde cheio: rotina completa. Contorno verde: dia com registros.</p>
<div class="card" style="margin-top:14px">${detail(csel)}</div>`}
function detail(k){const r=peek(k),d=fromIso(k),h=`<h3>${fmtLong(d)}</h3>`;
 if(!hasData(r))return h+'<p class="mu" style="margin:0">Nada registrado neste dia.</p>';
 const dn=S.tasks.filter(t=>r.done[t.id]).map(t=>esc(t.title)),hb=HAB.filter(([x])=>r.h[x]).map(([,n])=>n),dia=(r.diary.dia||'').trim();
 return h+`<p style="margin:0 0 6px">Rotina: <b>${pct(k)}%</b> · Água: <b>${r.water}</b> copos · Sono: <b>${r.sleep!=null?r.sleep+' h':'—'}</b></p>
<p class="mu" style="margin:0 0 6px">Hábitos: ${hb.join(', ')||'nenhum'}</p><p class="mu" style="margin:0 0 6px">Concluídas: ${dn.join(', ')||'nenhuma'}</p>
${dia?`<p style="margin:0 0 6px">“${esc(dia.slice(0,140))}${dia.length>140?'…':''}”</p>`:''}<button class="btn" data-a="od" data-k="${k}">Abrir no diário</button>`}

/* ---------- Tela: Progresso ---------- */
const lastDays=n=>Array.from({length:n},(_,i)=>{const d=new Date();d.setDate(d.getDate()-(n-1-i));return iso(d)});
const weeks=n=>Array.from({length:n},(_,i)=>{const d=new Date();d.setDate(d.getDate()-d.getDay()-7*(n-1-i));return Array.from({length:7},(_,j)=>{const e=new Date(d);e.setDate(d.getDate()+j);return iso(e)}).filter(k=>k<=today)});
function chart(vals,labels,max,goal){const n=vals.length,W=300,H=90,bw=W/n,g=bw*.28;
 let s=`<svg viewBox="0 0 ${W} ${H+16}" class="ch" role="img">`;
 if(goal!=null)s+=`<line x1="0" x2="${W}" y1="${H-goal/max*H}" y2="${H-goal/max*H}" class="gl"/>`;
 vals.forEach((v,i)=>{const x=i*bw+g/2;
  s+=v==null?`<rect x="${x}" y="${H-2}" width="${bw-g}" height="2" rx="1" class="nb"/>`:`<rect x="${x}" y="${H-Math.max(2,Math.min(v,max)/max*H)}" width="${bw-g}" height="${Math.max(2,Math.min(v,max)/max*H)}" rx="3" class="br"/>`;
  s+=`<text x="${x+(bw-g)/2}" y="${H+12}" class="lb">${labels[i]}</text>`});
 return s+'</svg>'}
const avg=a=>a.length?(a.reduce((x,y)=>x+y,0)/a.length):null;
function vProg(){const ks=Object.keys(S.days).filter(k=>hasData(S.days[k])),d14=lastDays(14),lb=d14.map(k=>+k.slice(8)),w6=weeks(6),wl=w6.map(w=>w[0].slice(8)+'/'+w[0].slice(5,7));
 const sleeps=ks.map(k=>S.days[k].sleep).filter(v=>v!=null),waters=ks.map(k=>S.days[k].water).filter(v=>v>0);
 const gym28=lastDays(28).filter(k=>peek(k)&&peek(k).h.gym).length,sa=avg(sleeps),wa=avg(waters);
 const reg=k=>hasData(peek(k)),wkHas=w=>w.some(k=>reg(k));
 if(!ks.length)return`<header class="hero"><h1>Progresso</h1></header><div class="card"><p class="mu" style="margin:0">Ainda sem registros. Use o app por alguns dias e seus gráficos aparecem aqui. Só mostro o que você registrou.</p></div>`;
 return`<header class="hero"><h1>Progresso</h1></header><div class="st">
<div class="card"><b>${ks.filter(complete).length}</b><span>dias com rotina completa</span></div><div class="card"><b>${gym28}</b><span>treinos em 28 dias</span></div>
<div class="card"><b>${sa!=null?sa.toFixed(1)+' h':'—'}</b><span>média de sono</span></div><div class="card"><b>${wa!=null?wa.toFixed(1):'—'}</b><span>média de copos por dia</span></div></div>
<div class="card"><h3>Rotina concluída (14 dias, %)</h3>${chart(d14.map(k=>reg(k)?pct(k):null),lb,100)}</div>
<div class="card"><h3>Treinos por semana</h3>${chart(w6.map(w=>wkHas(w)?w.filter(k=>peek(k)&&peek(k).h.gym).length:null),wl,7)}</div>
<div class="card"><h3>Horas de sono (14 dias, meta 8 h)</h3>${chart(d14.map(k=>peek(k)?peek(k).sleep:null),lb,12,8)}</div>
<div class="card"><h3>Água (14 dias, meta ${S.set.water} copos)</h3>${chart(d14.map(k=>peek(k)&&peek(k).water>0?peek(k).water:null),lb,Math.max(S.set.water,...d14.map(k=>peek(k)?peek(k).water:0)),S.set.water)}</div>
<div class="card"><h3>Consistência semanal (média dos dias registrados, %)</h3>${chart(w6.map(w=>{const x=w.filter(reg);return x.length?Math.round(avg(x.map(pct))):null}),wl,100)}</div>`}

/* ---------- Tela: Diário ---------- */
const Q=[['dia','Como foi meu dia?'],['bom','O que fiz de bom?'],['melhorar','O que posso melhorar?'],['disp','Como está minha disposição?'],['amanha','Quais são minhas prioridades para amanhã?']];
function vDia(){const r=peek(dsel)||{diary:{}};
 return`<header class="hero"><h1>Diário</h1></header><div class="nav"><button class="rb" data-a="dn" data-d="-1" aria-label="Dia anterior">‹</button><b>${dsel===today?'Hoje, ':''}${fmtLong(fromIso(dsel))}</b><button class="rb" data-a="dn" data-d="1" aria-label="Próximo dia" ${dsel>=today?'disabled':''}>›</button></div>
${Q.map(([k,q])=>`<label class="fl">${q}<textarea rows="3" data-f="d:${k}">${esc(r.diary[k]||'')}</textarea></label>`).join('')}<p class="mu small" id="saved">As anotações são salvas automaticamente.</p>`}

/* ---------- Tela: Ajustes ---------- */
const chips=(g)=>DOWS.map((n,i)=>`<button class="chip${S.set[g].includes(i)?' on':''}" data-a="dy" data-g="${g}" data-d="${i}">${n}</button>`).join('');
function vAj(){S.tasks.sort((a,b)=>a.time.localeCompare(b.time));const perm=window.Notification?Notification.permission:'indisponível';
 return`<header class="hero"><h1>Ajustes</h1></header>
<div class="card"><div class="row"><span>Meta diária de água<br><span class="mu">${S.set.water} copos</span></span><div class="steps"><button class="rb" data-a="g-" aria-label="Diminuir meta">−</button><button class="rb on" data-a="g+" aria-label="Aumentar meta">+</button></div></div></div>
<div class="card"><h3>Dias de cardio</h3><div class="chips">${chips('cardio')}</div><h3 style="margin-top:16px">Dias de musculação</h3><div class="chips">${chips('train')}</div></div>
<div class="card"><div class="row"><span>Lembretes no app<br><span class="mu small">Avisam com o app aberto. Permissão: ${perm}</span></span><button class="chip${S.set.remind?' on':''}" data-a="rm">${S.set.remind?'Ativado':'Desativado'}</button></div>
<button class="btn pri" data-a="ics">Lembretes no Calendário do iPhone (.ics)</button><p class="mu small">Alternativa confiável: cria eventos diários com alarme no app Calendário.</p></div>
<h2>Tarefas e horários</h2>
${S.tasks.map(t=>`<div class="card"><div class="row2"><input type="time" value="${t.time}" data-t="${t.id}:time" aria-label="Horário"><input type="text" value="${t.kind==='gym'?'Musculação ou recuperação (muda por dia)':esc(t.title)}" data-t="${t.id}:title" ${t.kind==='gym'?'disabled':''} aria-label="Nome"></div><textarea rows="3" placeholder="Um item por linha (refeições, passos...)" data-t="${t.id}:items">${esc(t.items.join('\n'))}</textarea><div class="row"><label class="ck"><input type="checkbox" data-t="${t.id}:opt" ${t.opt?'checked':''}> Opcional</label><button class="lnk" data-a="del" data-id="${t.id}">Excluir</button></div></div>`).join('')}
<button class="btn" data-a="add">Adicionar tarefa</button><button class="btn" data-a="def">Restaurar tarefas padrão</button>
<h2>Backup dos dados</h2><div class="card"><button class="btn pri" style="margin-top:0" data-a="exp">Exportar backup</button><button class="btn" data-a="cpy">Copiar backup</button><button class="btn" data-a="imp">Importar backup</button><input type="file" id="file" accept="application/json,.json" hidden><button class="lnk" data-a="rst">Apagar todos os dados</button></div>`}

/* ---------- Arquivos: backup e calendário ---------- */
async function deliver(name,text,type){const f=new File([text],name,{type});
 try{if(navigator.canShare&&navigator.canShare({files:[f]})){await navigator.share({files:[f],title:name});return}}catch(e){if(e.name==='AbortError')return}
 const a=document.createElement('a');a.href=URL.createObjectURL(f);a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),4000)}
function ics(){const d=today.replace(/-/g,''),Z=new Date().toISOString().replace(/[-:]/g,'').slice(0,15)+'Z',e=s=>String(s).replace(/([,;\\])/g,'\\$1').replace(/\n/g,'\\n'),W=['SU','MO','TU','WE','TH','FR','SA'];
 const L=['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//Minha Rotina//PT','CALSCALE:GREGORIAN'];
 S.tasks.forEach(t=>{if(t.kind==='cardio'&&!S.set.cardio.length)return;const[h,m]=t.time.split(':');
  const rule=t.kind==='cardio'?'FREQ=WEEKLY;BYDAY='+S.set.cardio.map(i=>W[i]).join(','):'FREQ=DAILY';
  L.push('BEGIN:VEVENT',`UID:${t.id}@minharotina`,`DTSTAMP:${Z}`,`DTSTART:${d}T${h}${m}00`,'DURATION:PT15M','RRULE:'+rule,'SUMMARY:'+e(t.title),'DESCRIPTION:'+e(t.items.join(', ')),'BEGIN:VALARM','TRIGGER:PT0M','ACTION:DISPLAY','DESCRIPTION:'+e(t.title),'END:VALARM','END:VEVENT')});
 L.push('END:VCALENDAR');return L.join('\r\n')}

/* ---------- Lembretes com o app aberto ---------- */
async function ask(){if(!window.Notification){toast('Notificações indisponíveis. Use o calendário (.ics).');return}
 try{await Notification.requestPermission()}catch(e){}}
async function ping(t){toast(`${t.time} · ${t.title}`);
 if(window.Notification&&Notification.permission==='granted'){try{const reg=await navigator.serviceWorker.ready;reg.showNotification('Minha Rotina',{body:`${t.time} — ${t.title}`,icon:'icons/icon-192.png',tag:t.id})}catch(e){}}}
function tick(){const n=new Date(),k=iso(n);
 if(k!==today){today=k;csel=k;dsel=k;cfocus=n;render();return}
 const c=$('#clock');if(c)c.textContent=`${pad(n.getHours())}:${pad(n.getMinutes())}:${pad(n.getSeconds())}`;
 const g=$('#greet');if(g){const h=n.getHours();g.textContent=h<12?'Bom dia':h<18?'Boa tarde':'Boa noite'}
 const m=hm(n);if(m!==lastMin){lastMin=m;if(tab==='hoje'&&$('#nx')&&document.activeElement.id!=='sleep')paintHoje();
  if(S.set.remind){const r=day(today);tasksFor(today).filter(t=>t.time===m&&!r.done[t.id]).forEach(ping)}}}

/* ---------- Render e eventos ---------- */
function render(keep){const y=scrollY;$('#view').innerHTML={hoje:vHoje,cal:vCal,prog:vProg,diario:vDia,aj:vAj}[tab]();
 $('#tabs').innerHTML=TABS.map(([k,n])=>`<button class="${k===tab?'on':''}" data-a="tab" data-v="${k}" aria-label="${n}">${svg(IC[k])}${n}</button>`).join('');
 if(tab==='hoje')paintHoje();tick();scrollTo(0,keep?y:0)}
document.addEventListener('click',async e=>{const b=e.target.closest('[data-a]');if(!b)return;const a=b.dataset.a,d=b.dataset;
 switch(a){
 case'tab':tab=d.v;render();break;
 case't':toggleTask(d.id);break;
 case'x':open.has(d.id)?open.delete(d.id):open.add(d.id);paintHoje();break;
 case'w+':day(today).water++;save();paintHoje();break;
 case'w-':{const r=day(today);r.water=Math.max(0,r.water-1);save();paintHoje();break}
 case'h':{const r=day(today);r.h[d.k]=!r.h[d.k];save();paintHoje();break}
 case'cs':csel=d.k;render(true);break;
 case'cm':cmode=d.m;render(true);break;
 case'cn':{const n=new Date(cfocus),s=Number(d.d);if(cmode==='mes')n.setMonth(n.getMonth()+s,1);else n.setDate(n.getDate()+7*s);cfocus=n;render(true);break}
 case'od':dsel=d.k;tab='diario';render();break;
 case'dn':{const n=fromIso(dsel);n.setDate(n.getDate()+Number(d.d));if(iso(n)<=today)dsel=iso(n);render(true);break}
 case'g+':case'g-':S.set.water=Math.max(1,Math.min(30,S.set.water+(a==='g+'?1:-1)));save();render(true);break;
 case'dy':{const g=S.set[d.g],i=Number(d.d);g.includes(i)?g.splice(g.indexOf(i),1):g.push(i);save();render(true);break}
 case'rm':if(!S.set.remind)await ask();S.set.remind=!S.set.remind;save();render(true);break;
 case'ics':deliver('minha-rotina-lembretes.ics',ics(),'text/calendar');break;
 case'exp':deliver(`minha-rotina-backup-${today}.json`,JSON.stringify(S),'application/json');break;
 case'cpy':navigator.clipboard.writeText(JSON.stringify(S)).then(()=>toast('Backup copiado'),()=>toast('Não foi possível copiar'));break;
 case'imp':$('#file').click();break;
 case'rst':if(confirm('Apagar todos os dados? Esta ação não pode ser desfeita.')){localStorage.removeItem(KEY);S=load();render()}break;
 case'add':S.tasks.push(T('t'+Date.now().toString(36),'12:00','Nova tarefa',[]));save();render(true);break;
 case'del':if(confirm('Excluir esta tarefa?')){S.tasks=S.tasks.filter(t=>t.id!==d.id);save();render(true)}break;
 case'def':if(confirm('Restaurar as tarefas padrão? Suas edições de tarefas serão perdidas (o histórico fica).')){S.tasks=JSON.parse(JSON.stringify(DEFAULT_TASKS));save();render(true)}break}});
document.addEventListener('input',e=>{const t=e.target,f=t.dataset.f;
 if(f){if(f==='sleep')day(today).sleep=t.value===''?null:Math.min(16,Math.max(0,+t.value));else if(f.startsWith('d:'))day(dsel).diary[f.slice(2)]=t.value;save()}
 if(t.dataset.t&&t.type!=='checkbox'){const[id,k]=t.dataset.t.split(':'),x=S.tasks.find(z=>z.id===id);
  if(x){x[k]=k==='items'?t.value.split('\n').map(s=>s.trim()).filter(Boolean):t.value||x[k];save()}}});
document.addEventListener('change',async e=>{const t=e.target;
 if(t.id==='file'&&t.files[0]){try{const x=JSON.parse(await t.files[0].text());if(!x.tasks||!x.days)throw 0;
  if(confirm('Substituir os dados atuais pelo backup?')){S=norm(x);save();render();toast('Backup restaurado')}}catch(_){toast('Arquivo de backup inválido')}t.value=''}
 if(t.dataset.t){const[id,k]=t.dataset.t.split(':'),x=S.tasks.find(z=>z.id===id);
  if(x&&k==='opt'){x.opt=t.checked;save()}if(x&&k==='time'){save();render(true)}}});
document.addEventListener('visibilitychange',()=>{if(!document.hidden)tick()});
setInterval(tick,1000);render();
if('serviceWorker' in navigator)addEventListener('load',()=>navigator.serviceWorker.register('sw.js').catch(()=>{}));
