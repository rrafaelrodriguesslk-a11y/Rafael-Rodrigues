# Minha Rotina — como usar

## Testar no computador
Na pasta do projeto: `python3 -m http.server 8000` e abra http://localhost:8000
(abrir o index.html direto não ativa o modo offline; o service worker exige http/https).

## Publicar de graça (escolha uma)
- **Netlify Drop** (mais fácil): acesse app.netlify.com/drop e arraste a pasta `minha-rotina`. Em segundos você recebe um link https.
- **GitHub Pages**: crie um repositório público, envie todos os arquivos, vá em Settings > Pages > Branch main > Save.
- **Cloudflare Pages**: Workers & Pages > Create > Pages > Upload assets.

## Instalar no iPhone
1. Abra o link no **Safari**. 2. Toque em Compartilhar. 3. "Adicionar à Tela de Início". 4. Abra pelo ícone.

## Lembretes (limitação do iPhone)
Sem servidor, o iPhone não dispara notificações com o app fechado. O app avisa com ele aberto.
Alternativa gratuita e confiável: Ajustes > "Lembretes no Calendário (.ics)". Abra o arquivo e adicione os eventos; o Calendário toca o alarme em cada horário. Se o download falhar no app instalado, faça isso pelo Safari.

## Backup
Ajustes > Exportar backup (salve em Arquivos/iCloud) ou Copiar backup (cole em Notas). Para restaurar: Importar backup. Faça isso de vez em quando: se limpar os dados do Safari, o histórico se perde.

## Atualizar o app
Substitua os arquivos no mesmo endereço. Se mudar a rotina padrão, aumente o número em `sw.js` (minha-rotina-v1).
